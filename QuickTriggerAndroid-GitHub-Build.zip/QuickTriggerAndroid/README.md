# Quick Trigger (Android)

Aplikasi Android sederhana dengan tombol pemicu mengambang dan ON/OFF.

## Perilaku
1. Pengguna mengaktifkan `AUTO ON` pada overlay.
2. Pengguna menyentuh overlay `TAP 1` (bisa digeser, posisikan dekat tombol 1 pada game).
3. Aplikasi mengirim satu ketukan layar ke koordinat tombol 1.
4. Setelah jeda 1.000 ms, aplikasi mengirim dua ketukan ke koordinat tombol 2 dengan jarak awal 90 ms.

## Batasan penting
- Tombol `TAP 1` adalah pemicu pengganti yang mengambang. Aplikasi biasa tidak dapat secara andal mendeteksi sentuhan pada tombol game asli yang digambar sebagai elemen grafis/OpenGL tanpa root atau teknik injeksi. Karena itu, sentuh `TAP 1`, bukan tombol game asli.
- Koordinat awal diambil secara perkiraan dari screenshot: tombol 1 X=79%, Y=68,5%; tombol 2 X=78,2%, Y=40,5%. Periksa dan sesuaikan pada perangkatmu melalui halaman pengaturan.
- Game harus berada pada orientasi dan tata letak layar yang sama. Perubahan resolusi, rasio layar, HUD, atau skala kontrol mungkin memerlukan kalibrasi ulang.
- Aplikasi tidak memodifikasi APK game, tidak menggunakan root, tidak membaca teks/isi layar, dan tidak memiliki izin internet.
- Penggunaan macro dapat melanggar aturan game atau memicu sistem anti-cheat. Gunakan hanya sesuai aturan game.

## Build otomatis lewat GitHub (tanpa Android Studio)

Project ini sudah dilengkapi workflow `.github/workflows/build-apk.yml`. GitHub akan mengompilasi APK di server saat ada push ke branch `main`/`master`, atau saat workflow dijalankan manual.

1. Buat repository baru di GitHub.
2. Ekstrak ZIP project ini, lalu unggah **isi folder `QuickTriggerAndroid`** ke root repository (termasuk folder tersembunyi `.github`). Jangan mengunggah folder pembungkus `QuickTriggerAndroid` sebagai subfolder.
3. Pastikan file `.github/workflows/build-apk.yml` ada di repository.
4. Buka tab **Actions** pada repository. Pilih **Build Quick Trigger APK**, lalu **Run workflow**. Push ke `main` atau `master` juga otomatis memulai build.
5. Tunggu workflow berstatus hijau **Success**. Buka run tersebut, cari bagian **Artifacts**, lalu unduh `QuickTrigger-debug-apk`.
6. Ekstrak file artifact ZIP yang diunduh. Di dalamnya terdapat `app-debug.apk` yang dapat dipasang di Android.

Workflow menggunakan Java 17, Android SDK 35, dan Gradle 8.9. Tidak perlu memasang Android Studio atau menyimpan password/API key di GitHub. Artifact disimpan selama 7 hari.

**Catatan:** APK yang dihasilkan adalah APK debug, belum ditandatangani dengan kunci rilis pribadi.

## Penggunaan
1. Instal APK hasil build.
2. Buka Quick Trigger, sesuaikan koordinat/waktu bila perlu, lalu simpan.
3. Buka pengaturan Aksesibilitas dari tombol di aplikasi.
4. Aktifkan layanan **Quick Trigger**.
5. Kembali ke game, hidupkan `AUTO ON`, lalu sentuh overlay `TAP 1`.
6. Seret overlay `TAP 1` untuk memindahkannya. Posisi tersimpan.

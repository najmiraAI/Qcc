package com.quicktrigger.tap

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(TriggerAccessibilityService.PREFS, MODE_PRIVATE) }

    private lateinit var x1: EditText
    private lateinit var y1: EditText
    private lateinit var x2: EditText
    private lateinit var y2: EditText
    private lateinit var delay: EditText
    private lateinit var interval: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(245, 247, 250))
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "Quick Trigger"
            textSize = 28f
            setTextColor(Color.rgb(25, 35, 52))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Pemicu ketukan otomatis yang ringan"
            textSize = 14f
            setTextColor(Color.rgb(93, 103, 119))
            setPadding(0, dp(5), 0, dp(18))
        })

        root.addView(sectionTitle("Urutan tindakan"))
        root.addView(bodyText("Sentuh tombol mengambang “TAP 1” → Quick Trigger mengetuk posisi tombol 1 → menunggu 1 detik → mengetuk posisi tombol 2 dua kali."))
        root.addView(bodyText("Tombol pemicu mengambang berada di dekat tombol 1 dan bisa digeser. Ini diperlukan karena sentuhan pada tombol game asli tidak dapat dideteksi secara andal oleh aplikasi biasa."))

        root.addView(sectionTitle("Koordinat tombol (persen layar)"))
        root.addView(bodyText("Nilai awal diperkirakan dari screenshot yang kamu kirim. X dihitung dari kiri, Y dari atas."))

        root.addView(sectionTitle("Tombol 1"))
        var pair = fieldRow()
        x1 = addField(pair, "X (%)", prefs.getFloat("x1", 79.0f).toString())
        y1 = addField(pair, "Y (%)", prefs.getFloat("y1", 68.5f).toString())
        root.addView(pair)

        root.addView(sectionTitle("Tombol 2"))
        pair = fieldRow()
        x2 = addField(pair, "X (%)", prefs.getFloat("x2", 78.2f).toString())
        y2 = addField(pair, "Y (%)", prefs.getFloat("y2", 40.5f).toString())
        root.addView(pair)

        root.addView(sectionTitle("Pengaturan waktu"))
        pair = fieldRow()
        delay = addField(pair, "Jeda (ms)", prefs.getInt("delay", 1000).toString(), decimal = false)
        interval = addField(pair, "Jarak 2 klik (ms)", prefs.getInt("interval", 90).toString(), decimal = false)
        root.addView(pair)

        val save = Button(this).apply {
            text = "Simpan pengaturan"
            isAllCaps = false
            setOnClickListener { saveSettings() }
        }
        root.addView(save, marginTopParams(dp(18)))

        root.addView(sectionTitle("Aktifkan di Android"))
        root.addView(bodyText("1. Tekan tombol di bawah.\n2. Cari “Quick Trigger” pada daftar Accessibility / Aksesibilitas.\n3. Aktifkan layanan tersebut.\n4. Kembali ke game. Gunakan tombol kecil AUTO ON/OFF untuk mengaktifkan macro."))
        val access = Button(this).apply {
            text = "Buka pengaturan Aksesibilitas"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access, marginTopParams(dp(8)))

        root.addView(TextView(this).apply {
            text = "Privasi: aplikasi tidak meminta internet, tidak membaca isi layar, dan tidak mengubah APK game. Layanan aksesibilitas hanya dipakai untuk menampilkan pemicu dan mengirim ketukan layar."
            textSize = 12f
            setTextColor(Color.rgb(105, 112, 124))
            setPadding(0, dp(18), 0, 0)
        })

        setContentView(scroll)
    }

    private fun saveSettings() {
        val a = readFloat(x1, "X tombol 1") ?: return
        val b = readFloat(y1, "Y tombol 1") ?: return
        val c = readFloat(x2, "X tombol 2") ?: return
        val d = readFloat(y2, "Y tombol 2") ?: return
        val e = delay.text.toString().toIntOrNull()
        val f = interval.text.toString().toIntOrNull()
        if (e == null || e !in 100..5000) {
            delay.error = "Isi 100–5000 ms"
            return
        }
        if (f == null || f !in 40..1000) {
            interval.error = "Isi 40–1000 ms"
            return
        }
        prefs.edit()
            .putFloat("x1", a).putFloat("y1", b)
            .putFloat("x2", c).putFloat("y2", d)
            .putInt("delay", e).putInt("interval", f)
            .apply()
        Toast.makeText(this, "Pengaturan tersimpan", Toast.LENGTH_SHORT).show()
    }

    private fun readFloat(field: EditText, label: String): Float? {
        val value = field.text.toString().trim().replace(',', '.').toFloatOrNull()
        if (value == null || value !in 0f..100f) {
            field.error = "$label harus 0–100"
            return null
        }
        return value
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(Color.rgb(35, 48, 68))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(17), 0, dp(7))
    }

    private fun bodyText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(90, 100, 115))
        setPadding(0, 0, 0, dp(5))
    }

    private fun fieldRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun addField(row: LinearLayout, label: String, value: String, decimal: Boolean = true): EditText {
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.rgb(95, 105, 120))
        })
        val edit = EditText(this).apply {
            setText(value)
            textSize = 16f
            singleLine = true
            inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                        else InputType.TYPE_CLASS_NUMBER
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.WHITE)
        }
        column.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        if (row.childCount > 0) lp.leftMargin = dp(10)
        row.addView(column, lp)
        return edit
    }

    private fun marginTopParams(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

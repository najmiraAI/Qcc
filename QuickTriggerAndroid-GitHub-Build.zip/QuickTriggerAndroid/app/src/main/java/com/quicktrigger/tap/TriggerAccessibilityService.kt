package com.quicktrigger.tap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs

class TriggerAccessibilityService : AccessibilityService() {
    companion object {
        const val PREFS = "quick_trigger_settings"
    }

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var toggleView: TextView? = null
    private var triggerView: TextView? = null
    private var toggleParams: WindowManager.LayoutParams? = null
    private var triggerParams: WindowManager.LayoutParams? = null
    private var macroEnabled = false
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showControls()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Tidak membaca teks, hierarchy, atau isi layar game.
    }

    override fun onInterrupt() {
        busy = false
        updateTriggerLabel()
    }

    override fun onDestroy() {
        removeControls()
        super.onDestroy()
    }

    private fun showControls() {
        if (toggleView != null || triggerView != null) return
        val display = Point()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealSize(display)

        toggleView = makePill("AUTO OFF", Color.rgb(75, 83, 96)).apply {
            contentDescription = "Aktif/nonaktifkan Quick Trigger"
            setOnClickListener {
                macroEnabled = !macroEnabled
                updateToggleLabel()
                updateTriggerLabel()
            }
        }
        val toggleSize = dp(92)
        toggleParams = overlayParams(toggleSize, dp(40)).apply {
            x = dp(58)
            y = dp(10)
        }
        windowManager.addView(toggleView, toggleParams)

        triggerView = makePill("TAP 1", Color.rgb(36, 93, 204)).apply {
            contentDescription = "Pemicu: ketuk tombol 1, tunggu, lalu ketuk tombol 2 dua kali"
        }
        val triggerSizeW = dp(76)
        val triggerSizeH = dp(50)
        val storedX = getSharedPreferences(PREFS, MODE_PRIVATE).getInt("trigger_x", -1)
        val storedY = getSharedPreferences(PREFS, MODE_PRIVATE).getInt("trigger_y", -1)
        triggerParams = overlayParams(triggerSizeW, triggerSizeH).apply {
            x = if (storedX >= 0) storedX else (display.x * 0.88f - triggerSizeW / 2f).toInt().coerceAtLeast(0)
            y = if (storedY >= 0) storedY else (display.y * 0.685f - triggerSizeH / 2f).toInt().coerceAtLeast(0)
        }
        installDragAndTap(triggerView!!)
        windowManager.addView(triggerView, triggerParams)
        updateToggleLabel()
        updateTriggerLabel()
    }

    private fun makePill(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.argb(110, 255, 255, 255))
        }
        elevation = dp(6).toFloat()
        isClickable = true
        isFocusable = false
    }

    private fun overlayParams(width: Int, height: Int) = WindowManager.LayoutParams(
        width,
        height,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
    }

    private fun installDragAndTap(view: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { _, event ->
            val params = triggerParams ?: return@setOnTouchListener true
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = (startX + dx).toInt().coerceAtLeast(0)
                        params.y = (startY + dy).toInt().coerceAtLeast(0)
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putInt("trigger_x", params.x)
                            .putInt("trigger_y", params.y)
                            .apply()
                    } else {
                        runMacro()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun runMacro() {
        if (!macroEnabled || busy) return
        busy = true
        updateTriggerLabel()

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val delayMs = prefs.getInt("delay", 1000).toLong().coerceIn(100L, 5000L)
        val intervalMs = prefs.getInt("interval", 90).toLong().coerceIn(40L, 1000L)

        tapAtPercent(prefs.getFloat("x1", 79.0f), prefs.getFloat("y1", 68.5f)) { firstOk ->
            if (!firstOk) {
                finishMacro()
                return@tapAtPercent
            }
            handler.postDelayed({
                tapAtPercent(prefs.getFloat("x2", 78.2f), prefs.getFloat("y2", 40.5f)) { secondOk ->
                    if (!secondOk) {
                        finishMacro()
                        return@tapAtPercent
                    }
                    handler.postDelayed({
                        tapAtPercent(prefs.getFloat("x2", 78.2f), prefs.getFloat("y2", 40.5f)) {
                            finishMacro()
                        }
                    }, intervalMs)
                }
            }, delayMs)
        }
    }

    private fun tapAtPercent(xPercent: Float, yPercent: Float, done: (Boolean) -> Unit) {
        val display = Point()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealSize(display)
        val x = display.x * (xPercent.coerceIn(0f, 100f) / 100f)
        val y = display.y * (yPercent.coerceIn(0f, 100f) / 100f)
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 55)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                done(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                done(false)
            }
        }, handler)
        if (!accepted) done(false)
    }

    private fun finishMacro() {
        busy = false
        updateTriggerLabel()
    }

    private fun updateToggleLabel() {
        toggleView?.apply {
            text = if (macroEnabled) "AUTO ON" else "AUTO OFF"
            background = GradientDrawable().apply {
                setColor(if (macroEnabled) Color.rgb(33, 142, 91) else Color.rgb(75, 83, 96))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.argb(110, 255, 255, 255))
            }
        }
    }

    private fun updateTriggerLabel() {
        triggerView?.apply {
            text = when {
                busy -> "WAIT"
                !macroEnabled -> "TAP 1"
                else -> "TAP 1"
            }
            alpha = if (macroEnabled && !busy) 1f else 0.62f
        }
    }

    private fun removeControls() {
        toggleView?.let { runCatching { windowManager.removeView(it) } }
        triggerView?.let { runCatching { windowManager.removeView(it) } }
        toggleView = null
        triggerView = null
        toggleParams = null
        triggerParams = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
